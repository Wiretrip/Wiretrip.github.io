﻿function decodeUnsignedIntegers(encoded) 
{
	var numbers = [];
	var current = 0;
	var shift = 0;
	var i, ii;
	for (i = 0, ii = encoded.length; i < ii; ++i) 
	{
		var b = encoded.charCodeAt(i) - 63;
		current |= (b & 0x1f) << shift;
		if (b < 0x20) 
		{
			numbers.push(current);
			current = 0;
			shift = 0;
		} 
		else 
		{
			shift += 5;
		}
	}
	return numbers;
}

function decodeSignedIntegers(encoded) 
{
	var numbers = decodeUnsignedIntegers(encoded);
	var i, ii;
	for (i = 0, ii = numbers.length; i < ii; ++i) 
	{
		var num = numbers[i];
		numbers[i] = (num & 1) ? ~(num >> 1) : (num >> 1);
	}
	
	return numbers;
}

function decodeFloats(encoded, opt_factor) 
{
	var factor = 1e5;
	var numbers = decodeSignedIntegers(encoded);
	var i, ii;
	for (i = 0, ii = numbers.length; i < ii; ++i) 
	{
		numbers[i] /= factor;
	}
	return numbers;
}

function decodeDeltas(encoded, stride, opt_factor) 
{
	var factor = 1e5;
	var d;

	var lastNumbers = new Array(stride);
	for (d = 0; d < stride; ++d) 
	{
		lastNumbers[d] = 0;
	}

	var numbers = ol.format.Polyline.decodeFloats(encoded, factor);

	var i, ii;
	for (i = 0, ii = numbers.length; i < ii;) 
	{
		for (d = 0; d < stride; ++d, ++i) 
		{
			lastNumbers[d] += numbers[i];

			numbers[i] = lastNumbers[d];
		}
	}

	return numbers;
}

function decodePolyLineToCoords(text) 
{
	var linePoints = [];
	var flatCoordinates = ol.format.Polyline.decodeDeltas(text, 2, 1e5);
	for (i=0,ii=flatCoordinates.length;i<ii; i+=2)
	{
		linePoints.push([flatCoordinates[i+1],flatCoordinates[i]]);
	}
	return linePoints;
}



function showMap()
{
	this.map = new ol.Map({target: activityMap});
	var mapLayer = new ol.layer.Tile({
		source: new ol.source.XYZ({
		url: 'http://tile.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png',
		attributions: [new ol.Attribution({ html: ['&copy; <a href="http://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, &copy; <a href="http://cartodb.com/attributions">CartoDB</a>'] })]
		})
	})
	
	//var mapLayer = new ol.layer.Tile({source: new ol.source.OSM});
	map.addLayer(mapLayer);

	map.setView(new ol.View({center: [0, 0], zoom: 2, }));
}

function addWeatherFeature(segment, vectorSource)
{
	if ('undefined' !== typeof segment.weather)
	{
		var temp = segment.weather.temp;
		var windspeed = segment.weather.windSpeed;
		windspeed = (windspeed>40) ? 40 : windspeed;
		var windspeedScale = ((windspeed/40) * 0.2) + 0.2;
		
		var windIconFeature = new ol.Feature({geometry: new ol.geom.Point(ol.proj.transform([segment.start_longitude,segment.start_latitude], 'EPSG:4326','EPSG:900913')), name: segment.name});
		var windIconText = new ol.style.Text({textAlign: 'left', font: '12px helvetica,sans-serif', text: segment.weather.windSpeed+'mph ('+segment.weather.windDir+' - Gusts:'+segment.weather.windGust+'mph)', fill: new ol.style.Fill({color: '#aa0000'}), stroke: new ol.style.Stroke({color: '#ffffff', width: 1}), offsetX: 20, offsetY: 0});
		var windIconStyle = new ol.style.Style({image: new ol.style.Icon(({ anchor: [0.5,0.5], anchorXUnits: 'fraction', anchorYUnits: 'fraction', opacity: 0.95, rotation:(segment.weather.windDirDeg * (Math.PI / 180)), scale:windspeedScale, rotateWithView:true, src: 'img/winddir.png'})), text:windIconText});
		windIconFeature.setStyle(windIconStyle);
		vectorSource.addFeature(windIconFeature);
		
		var weatherIconFeature = new ol.Feature({geometry: new ol.geom.Point(ol.proj.transform([segment.start_longitude,segment.start_latitude], 'EPSG:4326','EPSG:900913')), name: segment.name});
		var weatherIconText = new ol.style.Text({textAlign: 'left', font: '12px helvetica,sans-serif', text: segment.weather.temp+'°C ('+((segment.weather.temp*1.8)+32)+'°F) '+segment.weather.description, fill: new ol.style.Fill({color: '#333'}), stroke: new ol.style.Stroke({color: '#ffffff', width: 1}), offsetX: 20, offsetY: 16});
		var weatherIconStyle = new ol.style.Style({image: new ol.style.Icon(({ anchor: [100,0.5], anchorXUnits: 'pixels', anchorYUnits: 'fraction', opacity: 0.95, scale:0.5, src: segment.weather.iconURL})), text:weatherIconText});
		weatherIconFeature.setStyle(weatherIconStyle);
		vectorSource.addFeature(weatherIconFeature);
		
		if ((segment.name=='Start') || (segment.name=='End'))	
		{
			var weatherTextFeature = new ol.Feature({geometry: new ol.geom.Point(ol.proj.transform([segment.start_longitude,segment.start_latitude], 'EPSG:4326','EPSG:900913')), name: segment.name});
			var weatherTextText = new ol.style.Text({textAlign: 'left', font: 'bold 12px helvetica,sans-serif', text: segment.name, fill: new ol.style.Fill({color: '#333'}), stroke: new ol.style.Stroke({color: '#ffffff', width: 1}), offsetX: 20, offsetY: -16});
			var weatherTextStyle = new ol.style.Style({text:weatherTextText});
			weatherTextFeature.setStyle(weatherTextStyle);
			vectorSource.addFeature(weatherTextFeature);
		}
		else
		{
			var weatherTextFeature = new ol.Feature({geometry: new ol.geom.Point(ol.proj.transform([segment.start_longitude,segment.start_latitude], 'EPSG:4326','EPSG:900913')), name: segment.name});
			var weatherTextText = new ol.style.Text({textAlign: 'left', font: 'bold 12px helvetica,sans-serif', text: 'Speed:'+segment.avg_mph+'mph Power:'+segment.avg_pwr+'W', fill: new ol.style.Fill({color: '#333'}), stroke: new ol.style.Stroke({color: '#ffffff', width: 1}), offsetX: 20, offsetY: -16});
			var weatherTextStyle = new ol.style.Style({text:weatherTextText});
			weatherTextFeature.setStyle(weatherTextStyle);
			vectorSource.addFeature(weatherTextFeature);
		}	
	}
	
}

function mapActivity(activity)
{
	if (map.getLayers().getLength()>1)
	{
		map.getLayers().removeAt(1);
	}
	
	//add the activity polyline
	var vectorSource = new ol.source.Vector();
	var vectorLayer = new ol.layer.Vector({source:vectorSource});
	map.addLayer(vectorLayer);

	var lineString = new ol.geom.LineString(decodePolyLineToCoords(activity.map.polyline));
	
	//add start and end markers
	var segment = [];
	var lineCoords=lineString.getCoordinates();
	segment.start_latitude=lineCoords[0][1];
	segment.start_longitude=lineCoords[0][0];
	segment.name="Start";
	segment.weather=activity.start_weather;
	addWeatherFeature(segment, vectorSource);
	
	segment.start_latitude=lineCoords[lineCoords.length-1][1];
	segment.start_longitude=lineCoords[lineCoords.length-1][0];
	segment.name="End";
	segment.weather=activity.end_weather;
	addWeatherFeature(segment, vectorSource);
	
	lineString.transform("EPSG:4326","EPSG:900913");
	var feature = new ol.Feature({geometry:lineString});
	feature.setStyle(new ol.style.Style({stroke: new ol.style.Stroke({color: '#ff0000', width: 4})}));
	vectorSource.addFeature(feature);
	
	
	//add segment markers
	for (i=0, ii=activity.segment_efforts.length; i<ii; i++) 
	{
		var segment_effort = activity.segment_efforts[i];
		segment_effort.segment.avg_mph = ((segment_effort.distance/segment_effort.elapsed_time) * 2.24).toFixed(2);
		segment_effort.segment.avg_pwr = segment_effort.average_watts;
		addWeatherFeature(segment_effort.segment, vectorSource);
	}


	var extent = vectorLayer.getSource().getExtent();
	map.getView().fitExtent(extent, map.getSize());
}


function loadActivity(id)
{
	$(".loadingSpinner").show();
	$.getJSON( 'http://127.0.0.1:8082/stravaweather/servlet/StravaWeatherServlet?act=activity&id='+id, 	
		function( data ) 
		{
			mapActivity(data);
			$(".loadingSpinner").hide();
		}
	);
}

function loadTestActivity()
{
	showMap();
	$(".loadingSpinner").show();
	$.getJSON( 'activity.json', 	
		function( data ) 
		{
			mapActivity(data);
			$(".loadingSpinner").hide();
		}
	);
}

function loadActivities()
{
	$(".loadingSpinner").show();
	$.getJSON( 'http://127.0.0.1:8082/stravaweather/servlet/StravaWeatherServlet?act=activities', 	
		function( activities ) 
		{
			for(i=0, ii=activities.length; i<ii; i++) 
			{
				var a = activities[i];
				var el = document.createElement("option");
				el.textContent = a.name+' on '+a.start_date;
				el.value = a.id;
				activitySelect.appendChild(el);
			}
			$(".loadingSpinner").hide();
		}
	);
	
	showMap();
}