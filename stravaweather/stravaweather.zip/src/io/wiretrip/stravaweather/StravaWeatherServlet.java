package io.wiretrip.stravaweather;


import com.gillcgroup.cid.CIDUser;
import io.wiretrip.stravaweather.dao.WeatherInfo;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.Inflater;
import java.util.zip.InflaterInputStream;

/**
 * Created by brendan on 14/02/2016.
 */
public class StravaWeatherServlet extends HttpServlet
{
    private HttpClient httpClient;
    private static DecimalFormat coordFmt = new DecimalFormat("###.###");
    private String dataDir, webappPath;

    private String clientID;
    private String clientSecret;
    private String weatherAPIAccessToken;

    public StravaWeatherServlet()
    {
    }

    /**
     * <p>
     * Standard init...
     * </p>
     */
    public void init(ServletConfig config) throws ServletException
    {
        super.init(config);

        this.dataDir=config.getServletContext().getRealPath("")+"/data/";

        final RequestConfig requestConfig = RequestConfig.custom()
                .setSocketTimeout(1200000)
                .setConnectTimeout(1200000)
                .setConnectionRequestTimeout(120000)
                .setRedirectsEnabled(true)
                .build();

        httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).build();

        this.webappPath = config.getInitParameter("webapp_path");
        this.clientID = config.getInitParameter("strava_client_id");
        this.clientSecret = config.getInitParameter("strava_client_secret");
        this.weatherAPIAccessToken = config.getInitParameter("weather_api_token");

        System.out.println(webappPath);
        System.out.println(clientID);
        System.out.println(clientSecret);
        System.out.println(weatherAPIAccessToken);
    }

    /**
     * <p>
     * Standard init...
     * </p>
     */
    public void init(final String dataDir, final String webappPath, final String clientID, final String clientSecret, final String weatherAPIAccessToken) throws ServletException
    {
        this.dataDir=dataDir;

        final RequestConfig requestConfig = RequestConfig.custom()
                .setSocketTimeout(1200000)
                .setConnectTimeout(1200000)
                .setConnectionRequestTimeout(120000)
                .setRedirectsEnabled(true)
                .build();

        httpClient = HttpClients.custom().setDefaultRequestConfig(requestConfig).build();

        this.webappPath = webappPath;
        this.clientID = clientID;
        this.clientSecret = clientSecret;
        this.weatherAPIAccessToken = weatherAPIAccessToken;

        System.out.println(webappPath);
        System.out.println(clientID);
        System.out.println(clientSecret);
        System.out.println(weatherAPIAccessToken);
    }

    /**
     * <p>
     * Standard doGet...
     * </p>
     */
    protected void doGet(HttpServletRequest incomingRequest, HttpServletResponse response)
            throws IOException, ServletException
    {
        response.setHeader("Cache-Control","no-cache");     // Disables caching for HTTP 1.1 onwards
        response.setHeader("Pragma","no-cache");            // Disables caching for HTTP 1.0
        response.setHeader("Expires","0");                  // Another command to do the same thing!
        response.setContentType("application/json; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        HttpSession curSess = incomingRequest.getSession();

        PrintWriter outWrt = new PrintWriter(new OutputStreamWriter(response.getOutputStream(),"UTF-8"));

        try
        {
            String act = (incomingRequest.getParameter("act")==null) ? "auth" : incomingRequest.getParameter("act");
            switch (act)
            {
                case "auth":
                {
                    String stravaAccessToken = getStravaAccessToken(this.clientID, this.clientSecret, incomingRequest.getParameter("code"));
                    System.out.println("Got access token:"+stravaAccessToken);
                    if (stravaAccessToken!=null)
                    {
                        curSess.setAttribute("strava_access_token", stravaAccessToken);
                        response.sendRedirect(webappPath + "activities.html");
                    }
                    break;
                }
                case "activities":
                {
                    outWrt.println(getStravaActivities((String) curSess.getAttribute("strava_access_token")).toString());
                    break;
                }
                case "activity":
                {
                    outWrt.println(this.getStravaActivityWithWeather((String) curSess.getAttribute("strava_access_token"), this.weatherAPIAccessToken, incomingRequest.getParameter("id")).toString());
                    break;
                }

            }
        }
        catch (Exception e)
        {
            outWrt.println("{\"error\":\""+e.getMessage()+"\"}");
        }
        finally
        {
            outWrt.close();
        }
    }

    private String streamToString(InputStream strmIn, String encoding) throws Exception
    {
        final StringBuilder strOut=new StringBuilder();

        if (strmIn!=null)
        {
            final BufferedReader rdr = new BufferedReader(new InputStreamReader(strmIn, encoding));

            String lineRead;
            while ((lineRead = rdr.readLine()) != null)
            {
                strOut.append(lineRead);
            }
        }
        return strOut.toString().trim();
    }

    private String getStravaAccessToken(final String clientID, final String clientSecret, final String authCode) throws Exception
    {
        HttpPost httpPost = null;
        InputStream responseStrm = null;
        try
        {
            System.out.println("Client:"+clientID+" sct:"+clientSecret+" code:"+authCode);

            httpPost = new HttpPost("https://www.strava.com/oauth/token");

            final List<NameValuePair> nvps = new ArrayList<NameValuePair>();
            nvps.add(new BasicNameValuePair("client_id", clientID));
            nvps.add(new BasicNameValuePair("client_secret", clientSecret));
            nvps.add(new BasicNameValuePair("code", authCode));
            httpPost.setEntity(new UrlEncodedFormEntity(nvps));

            final HttpResponse response = httpClient.execute(httpPost);
            int responseCode = response.getStatusLine().getStatusCode();
            System.out.println(responseCode);
            if ((responseCode>=200) && (responseCode<=204))
            {
                responseStrm = response.getEntity().getContent();

                String json = streamToString(responseStrm, "UTF-8");

                if (json.length()>0)
                {
                    JSONObject athleteInfo = new JSONObject(json);
                    if (athleteInfo.has("access_token"))
                    {
                        return athleteInfo.getString("access_token");
                    }
                    else
                    {
                        throw new Exception("getStravaAccessToken: no access token!");
                    }
                }
            }
        }
        finally
        {
            try{responseStrm.close();}catch(Exception e){};
            try{httpPost.releaseConnection();}catch(Exception e){};
        }

        return null;
    }

    private JSONObject getJSON(String url) throws Exception
    {
        HttpGet httpConnectionMethod = null;
        InputStream responseStrm = null;
        try
        {
            httpConnectionMethod = new HttpGet(url);
            httpConnectionMethod.setHeader("Accept-Encoding", "gzip,deflate");

            final HttpResponse response = httpClient.execute(httpConnectionMethod);
            int responseCode = response.getStatusLine().getStatusCode();
            if ((responseCode>=200) && (responseCode<=204))
            {
                responseStrm = response.getEntity().getContent();

                Header contentEncodingHeader = response.getEntity().getContentEncoding();
                if (contentEncodingHeader != null && contentEncodingHeader.getValue().equalsIgnoreCase("gzip"))
                    responseStrm=new GZIPInputStream(responseStrm);
                else if (contentEncodingHeader != null && contentEncodingHeader.getValue().equalsIgnoreCase("deflate"))
                    responseStrm=new InflaterInputStream(responseStrm, new Inflater(true));

                String json = streamToString(responseStrm, "UTF-8");
                if (json.length()>0)
                {
                    return new JSONObject(json);
                }
            }
            else
            {
                throw new Exception(response.getStatusLine().getReasonPhrase());
            }
        }
        finally
        {
            try{responseStrm.close();}catch(Exception e){};
            try{httpConnectionMethod.releaseConnection();}catch(Exception e){};
        }

        return null;
    }

    private JSONArray getJSONArray(String url) throws Exception
    {
        HttpGet httpConnectionMethod = null;
        InputStream responseStrm = null;
        try
        {
            httpConnectionMethod = new HttpGet(url);
            httpConnectionMethod.setHeader("Accept-Encoding", "gzip,deflate");

            final HttpResponse response = httpClient.execute(httpConnectionMethod);
            int responseCode = response.getStatusLine().getStatusCode();
            if ((responseCode>=200) && (responseCode<=204))
            {
                responseStrm = response.getEntity().getContent();

                Header contentEncodingHeader = response.getEntity().getContentEncoding();
                if (contentEncodingHeader != null && contentEncodingHeader.getValue().equalsIgnoreCase("gzip"))
                    responseStrm=new GZIPInputStream(responseStrm);
                else if (contentEncodingHeader != null && contentEncodingHeader.getValue().equalsIgnoreCase("deflate"))
                    responseStrm=new InflaterInputStream(responseStrm, new Inflater(true));

                String json = streamToString(responseStrm, "UTF-8");
                if (json.length()>0)
                {
                    return new JSONArray(json);
                }
            }
            else
            {
                throw new Exception(response.getStatusLine().getReasonPhrase());
            }
        }
        finally
        {
            try{responseStrm.close();}catch(Exception e){};
            try{httpConnectionMethod.releaseConnection();}catch(Exception e){};
        }

        return null;
    }

    private JSONArray getStravaActivities(final String accessToken) throws Exception
    {
           if (accessToken==null)
           {
               throw new Exception("getStravaActivities: no access token!");
           }

           JSONArray response = getJSONArray("https://www.strava.com/api/v3/athlete/activities?access_token=" + accessToken);
           if (response!=null)
           {
               return response;
           }
           else
           {
               throw new Exception("getStravaActivities: no response!");
           }
    }

    private JSONObject getStravaActivity(final String accessToken, final String activityID) throws Exception
    {
        JSONObject response = getJSON("https://www.strava.com/api/v3/activities/"+activityID+"/?access_token="+accessToken);
        if (response!=null)
        {
            return response;
        }
        else
        {
            throw new Exception("getStravaActivity: no response!");
        }
    }

    private void toFile(String filename, String text) throws Exception
    {
        OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(filename), "UTF-8");
        try
        {
            writer.write(text);
        }
        finally
        {
            writer.flush();
            writer.close();
        }
    }

    private String fromFile(String filename) throws Exception
    {
        StringBuilder buf = new StringBuilder();
        BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(filename), "UTF-8"));
        try
        {
            String line;
            while ((line=reader.readLine())!=null)
            {
                buf.append(line).append("\r\n");
            }

            return buf.toString();
        }
        finally
        {
            reader.close();
        }
    }

    private WeatherInfo getWeatherInfoByTimeAndLocation(final String accessToken, final long time, final double lat, final double lng) throws Exception
    {
        final String dateQuery = new SimpleDateFormat("yyyy-MM-dd").format(time);
        String urlParams = "?q="+coordFmt.format(lat)+","+coordFmt.format(lng)+"&date="+dateQuery;
        final byte[] digest =  MessageDigest.getInstance("MD5").digest(urlParams.toString().getBytes());
        final BigInteger bigInt = new BigInteger(1,digest);
        final String hash = bigInt.toString(16);

        JSONObject wwOnlineInfo = null;
        String tempFile = dataDir+hash+".json";
        if (new File(tempFile).exists())
        {
            wwOnlineInfo = new JSONObject(fromFile(tempFile));
        }
        else
        {
            urlParams+="&tp=1&format=json&key="+accessToken;
            try //try and fetch weather - accept the possibility of not being able to get any data
            {
                wwOnlineInfo = getJSON("https://api.worldweatheronline.com/free/v2/past-weather.ashx" + urlParams);
                toFile(tempFile, wwOnlineInfo.toString());
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }

        //parse info (selecting closest time slot)
        SimpleDateFormat dtFmt = new SimpleDateFormat("yyyy-MM-dd Hmm");
        if ((wwOnlineInfo!=null) && (wwOnlineInfo.has("data") && (wwOnlineInfo.getJSONObject("data").has("weather"))))
        {
            JSONObject weather = wwOnlineInfo.getJSONObject("data").getJSONArray("weather").getJSONObject(0);
            if (weather.has("hourly"))
            {
                JSONArray hourly = weather.getJSONArray("hourly");

                JSONObject curWeather = null;
                for (int i=0; i<hourly.length(); i++)
                {
                    curWeather = hourly.getJSONObject(i);
                    long curWeatherTime = dtFmt.parse(dateQuery+" "+curWeather.getString("time")+"00").getTime();
                    if (i==hourly.length()-1) //curWeather is the last observation, use that
                    {
                        break;
                    }

                    final JSONObject nextWeather = hourly.getJSONObject(i+1);
                    long nextWeatherTime = dtFmt.parse(dateQuery+" "+nextWeather.getString("time")+"00").getTime();
                    if (time < nextWeatherTime) //requested time is between curWeather and nextWeather
                    {
                        //select the closest observation to the requested time
                        //default is curWeather
                        if ((time-curWeatherTime)>(nextWeatherTime-time))
                        {
                            curWeather=nextWeather;
                        }
                        break;
                    }
                }

                return (curWeather!=null) ? WeatherInfo.fromWWAPIJson(curWeather) : null;
            }
        }

        return null;
    }

    private JSONObject getStravaActivityWithWeather(final String stravaAccessToken, final String weatherAccessToken, final String activityID) throws Exception
    {
        if (stravaAccessToken==null)
        {
            throw new Exception("addWeatherStravaActivity: no access token!");
        }

        final SimpleDateFormat stravaDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");


        final JSONObject activity = getStravaActivity(stravaAccessToken, activityID) ;

        if ((activity!=null) && (activity.has("segment_efforts")))
        {
            final JSONArray segmentEfforts = activity.getJSONArray("segment_efforts");
            for (int i=0; i<segmentEfforts.length(); i++)
            {
                final JSONObject segmentEffort = segmentEfforts.getJSONObject(i);
                if (segmentEffort.has("segment") && segmentEffort.has("start_date"))
                {
                    final long time = stravaDateFormat.parse(segmentEffort.getString("start_date")).getTime();
                    final JSONObject segment = segmentEffort.getJSONObject("segment");
                    if (segment.has("start_latlng"))
                    {
                        final JSONArray startLatLng = segment.getJSONArray("start_latlng");

                        WeatherInfo weather = getWeatherInfoByTimeAndLocation(weatherAccessToken, time, startLatLng.getDouble(0), startLatLng.getDouble(1));

                        if (weather!=null)
                        {
                            segment.put("weather",new JSONObject(weather));
                        }

                        Thread.currentThread().sleep(200);
                    }
                }

                if (activity.has("start_latlng") && activity.has("start_date"))
                {
                    final long time = stravaDateFormat.parse(activity.getString("start_date")).getTime();
                    final JSONArray startLatLng = activity.getJSONArray("start_latlng");

                    WeatherInfo weather = getWeatherInfoByTimeAndLocation(weatherAccessToken, time, startLatLng.getDouble(0), startLatLng.getDouble(1));

                    if (weather!=null)
                    {
                        activity.put("start_weather",new JSONObject(weather));
                    }

                    Thread.currentThread().sleep(200);
                }

                if (activity.has("end_latlng") && activity.has("start_date") && activity.has("elapsed_time"))
                {
                    long time = stravaDateFormat.parse(activity.getString("start_date")).getTime();
                    time += activity.getLong("elapsed_time")*1000;
                    final JSONArray endLatLng = activity.getJSONArray("end_latlng");

                    WeatherInfo weather = getWeatherInfoByTimeAndLocation(weatherAccessToken, time, endLatLng.getDouble(0), endLatLng.getDouble(1));

                    if (weather!=null)
                    {
                        activity.put("end_weather",new JSONObject(weather));
                    }

                    Thread.currentThread().sleep(200);
                }
            }


        }

        return activity;
    }

    public static void main(String[] args)
    {
        StravaWeatherServlet servlet = new StravaWeatherServlet();
        try
        {
            servlet.init("d:/tmp", "", "", "", "");
            System.out.println(servlet.getStravaActivityWithWeather("999074d3ef0b02a7a28ca20c116d74e7681d961d","2de978879d7f3def46495229aff6e","500237189").toString());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }

}
