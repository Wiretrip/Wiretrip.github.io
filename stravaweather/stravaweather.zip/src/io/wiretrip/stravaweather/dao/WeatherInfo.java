package io.wiretrip.stravaweather.dao;

import org.json.JSONObject;

/**
 * Created by brendan on 11/02/2016.
 */
public class WeatherInfo
{
    private long time;
    private float[] latLon;
    private int temp, windChill, windSpeed, windGust, windDirDeg;
    private String location, description, windDir, iconURL;

    public long getTime()
    {
        return time;
    }

    public void setTime(long time)
    {
        this.time = time;
    }

    public float[] getLatLon()
    {
        return latLon;
    }

    public void setLatLon(float[] latLon)
    {
        this.latLon = latLon;
    }


    public int getTemp()
    {
        return temp;
    }

    public void setTemp(int temp)
    {
        this.temp = temp;
    }

    public int getWindChill()
    {
        return windChill;
    }

    public void setWindChill(int windChill)
    {
        this.windChill = windChill;
    }

    public int getWindSpeed()
    {
        return windSpeed;
    }

    public void setWindSpeed(int windSpeed)
    {
        this.windSpeed = windSpeed;
    }

    public int getWindGust()
    {
        return windGust;
    }

    public void setWindGust(int windGust)
    {
        this.windGust = windGust;
    }

    public int getWindDirDeg()
    {
        return windDirDeg;
    }

    public void setWindDirDeg(int windDirDeg)
    {
        this.windDirDeg = windDirDeg;
    }

    public String getLocation()
    {
        return location;
    }

    public void setLocation(String location)
    {
        this.location = location;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public String getWindDir()
    {
        return windDir;
    }

    public void setWindDir(String windDir)
    {
        this.windDir = windDir;
    }

    public String getIconURL()
    {
        return iconURL;
    }

    public void setIconURL(String iconURL)
    {
        this.iconURL = iconURL;
    }

    public static WeatherInfo fromWWAPIJson(JSONObject curWeather) throws Exception
    {
        WeatherInfo weatherInfo = new WeatherInfo();
        weatherInfo.setDescription(curWeather.has("weatherDesc") ? curWeather.getJSONArray("weatherDesc").getJSONObject(0).getString("value") : "");
        //weatherInfo.setLatLon();
        weatherInfo.setTemp(curWeather.has("tempC") ? curWeather.getInt("tempC") : 0);
        //weatherInfo.setTime();
        weatherInfo.setWindChill(curWeather.has("WindChillC") ? curWeather.getInt("WindChillC") : 0);
        weatherInfo.setWindDir(curWeather.has("winddir16Point") ? curWeather.getString("winddir16Point") : "");
        weatherInfo.setWindDirDeg(curWeather.has("winddirDegree") ? curWeather.getInt("winddirDegree") : 0);
        weatherInfo.setWindSpeed(curWeather.has("windspeedMiles") ? curWeather.getInt("windspeedMiles") : 0);
        weatherInfo.setWindGust(curWeather.has("WindGustMiles") ? curWeather.getInt("WindGustMiles") : 0);
        weatherInfo.setIconURL(curWeather.has("weatherIconUrl") ? curWeather.getJSONArray("weatherIconUrl").getJSONObject(0).getString("value") : "");

        return weatherInfo;
    }
}
